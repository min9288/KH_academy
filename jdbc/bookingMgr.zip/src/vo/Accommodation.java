package vo;

public class Accommodation {

}
