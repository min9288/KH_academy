package vo;

public class Reservation {

}
