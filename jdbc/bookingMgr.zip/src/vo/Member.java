package vo;

public class Member {

}
