package view;

public class MemberView {

}
