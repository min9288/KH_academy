package dao;

public class StaffDao {

}
