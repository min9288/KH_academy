package start;

import controller.BookingController;

public class Start {

	public static void main(String[] args) {
		BookingController bc = new BookingController();
		bc.main();
	}

}
